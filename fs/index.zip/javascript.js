function periodicData()
            {
              respObj;
              var req = false;

              function periodicComplete()
              {
                if(req.readyState == 4)
                {
                  if(req.status == 200)
                  {
                    respObj = JSON.parse(req.responseText);
                    document.getElementById("periodic").innerHTML = "<div>" 
                                            + "Temperature: " + respObj.temperature + " "
                                            + "Humidity: " + respObj.humidity + " "
                                            + "Pressure: " + respObj.pressure + " "
                                            + "Light: " + respObj.light + " "
                                            + "</div>";
                  }
                }
              }

              if(window.XMLHttpRequest)
              {
                  req = new XMLHttpRequest();
              }
              else if(window.ActiveXObject)
              {
                  req = new ActiveXObject("Microsoft.XMLHTTP");
              }
              if(req)
              {
                  req.open("GET", "/cgi-bin/send_data?id" + Math.random(), true);
                  req.onreadystatechange = periodicComplete;
                  req.send(null);
              }
            }

function sendData()
{
    var req = false;

    function sendingComplete()
    {
        if(req.readyState == 4)
        {
            if(req.status == 200)
            {
            	respObj = JSON.parse(req.responseText);
                document.getElementById("data").innerHTML = "<div>" 
                	+ "Temperature: " + respObj.temperature + " "
                	+ "Humidity: " + respObj.humidity + " "
                	+ "Pressure: " + respObj.pressure + " "
                	+ "Light: " + respObj.light + " "
                    + "</div>";
            }
        }
    }

    if(window.XMLHttpRequest)
    {
        req = new XMLHttpRequest();
    }
    else if(window.ActiveXObject)
    {
        req = new ActiveXObject("Microsoft.XMLHTTP");
    }
    if(req)
    {
        req.open("GET", "/cgi-bin/send_data?id" + Math.random(), true);
        req.onreadystatechange = sendingComplete;
        req.send(null);
    }
}

/* arguments: 
    - sampleNum - number of samples showed at once
    - data - array of length 'sampleNum' containing the measurement data
    - random - temporal variable for testing
    - id - contains the ID of SVG HTML element
    - svg - the animation itselv
    - margin - margin of animation
    - width - animation width
    - height - animation height
    - g - SVG group element
    - x - x axis
    - y - y axis 
    - renderGraph - function for periodic rerendering
*/
function LineGraph(sampleNumber, elementID, period){
    this.period = period;
    this.sampleNum = sampleNumber;
    this.id = "#" + elementID;

    this.data = d3.range(this.sampleNum).map(d3.randomNormal(0, .3));
    console.log(this.data);

    this.svg = d3.select(this.id);
    this.margin = {top: 20, right: 20, bottom: 20, left: 40};
    this.width = +this.svg.attr("width") - this.margin.left - this.margin.right;
    this.height = +this.svg.attr("height") - this.margin.top - this.margin.bottom;
    this.g = this.svg.append("g").attr("transform", "translate(" + this.margin.left + "," + this.margin.top + ")");

    this.x = d3.scaleLinear()
               .domain([0, this.sampleNum - 1])
               .range([0, this.width]);

    this.y = d3.scaleLinear()
               .domain([-1, 1])
               .range([this.height, 0]);

    this.line = d3.line()
                    .x(function(d, i) { return x(i); })
                    .y(function(d, i) { return y(d); });

    this.renderGraph = function (){
        // Push a new data point onto the beginning.
        var newData = (d3.randomNormal(0, .3))();
        console.log(this.data);
        console.log(newData);
        console.log(this);
        this.data.unshift(newData);
        
        // Redraw the line.
        d3.select(this)
            .attr("d", this.line)
            .attr("transform", null);
    
        // Slide it to the right.
        d3.active(this)
            .attr("transform", "translate(" + x(+1) + ",0)")
            .transition()
            .on("start", this.renderGraph);
    
        // Pop the old data point off the back.
        this.data.pop();
    };

    this.initGraph = function(){
        this.g.append("defs").append("clipPath")
                        .attr("id", "clip")
                        .append("rect")
                        .attr("width", this.width)
                        .attr("height", this.height);
    
        this.g.append("g")
              .attr("class", "axis axis--x")
              .attr("transform", "translate(0," + this.y(0) + ")")
              .call(d3.axisBottom(this.x));
    
        this.g.append("g")
              .attr("class", "axis axis--y")
              .call(d3.axisLeft(this.y));
        
        this.g.append("g")
                   .attr("clip-path", "url(#clip)")
                   .append("path")
                   .datum(this.data)
            
                   .attr("class", "line")
                   .transition()
                   .duration(this.period)
                   .ease(d3.easeLinear)
                   .on("start", this.renderGraph);
    };
};

function initGraph(sampleNum, id){
    var n = sampleNum;
    random = d3.randomNormal(0, .3);
    data = d3.range(n).map(random);

    var id = "#" + id;

    var svg = d3.select(id),
        margin = {top: 20, right: 20, bottom: 20, left: 40},
        width = +svg.attr("width") - margin.left - margin.right,
        height = +svg.attr("height") - margin.top - margin.bottom,
        g = svg.append("g").attr("transform", "translate(" + margin.left + "," + margin.top + ")");

    var x = d3.scaleLinear()
        .domain([0, n - 1])
        .range([0, width]);

    var y = d3.scaleLinear()
        .domain([-1, 1])
        .range([height, 0]);

    line = d3.line()
        .x(function(d, i) { return x(i); })
        .y(function(d, i) { return y(d); });

    g.append("defs").append("clipPath")
        .attr("id", "clip")
        .append("rect")
        .attr("width", width)
        .attr("height", height);

    g.append("g")
        .attr("class", "axis axis--x")
        .attr("transform", "translate(0," + y(0) + ")")
        .call(d3.axisBottom(x));

    g.append("g")
        .attr("class", "axis axis--y")
        .call(d3.axisLeft(y));

    g.append("g")
        .attr("clip-path", "url(#clip)")
        .append("path")
        .datum(data)
    
        .attr("class", "line")
        .transition()
        .duration(1000)
        .ease(d3.easeLinear)
        .on("start", tick);

        function tick() {

            // Push a new data point onto the beginning.
            data.unshift(random());

            // Redraw the line.
            d3.select(this)
            .attr("d", line)
            .attr("transform", null);

            // Slide it to the right.
            d3.active(this)
            .attr("transform", "translate(" + x(+1) + ",0)")
            .transition()
            .on("start", tick);

            // Pop the old data point off the back.
            data.pop();
        };
}